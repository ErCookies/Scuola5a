import modf

PLANTS = (Entities.Grass,
			Entities.Tree,
			Entities.Carrot,
			Entities.Pumpkin)

while True:
	for crop in PLANTS:
		modf.hvPlLoop(crop)