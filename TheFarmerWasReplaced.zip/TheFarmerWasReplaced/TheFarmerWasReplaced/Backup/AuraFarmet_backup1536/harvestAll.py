import modf
modf.resetPos()
modf.harvLoop()