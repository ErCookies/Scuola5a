import modf

harvest()
modf.resetPos()