import modf
modf.resetPos()