def validTreePlacement():
	return (get_pos_x() % 2 == 0 and get_pos_y() % 2 == 0) or (get_pos_x() % 2 == 1 and get_pos_y() % 2 == 1)
###
def waterLoop():
	for k in range(get_world_size()):
		for j in range(get_world_size()):
			use_item(Items.Water)
			move(East)
		move(North)
###
def harvLoop():
	for k in range(get_world_size()):
		for j in range(get_world_size()):
			if(can_harvest() or get_entity_type() == Entities.Dead_Pumpkin):
				harvest()
			move(East)
		move(North)
###
def tillLoop():
	for k in range(get_world_size()):
		for j in range(get_world_size()):
			till()
			move(East)
		move(North)
###
def resetPos():
	for k in range(get_pos_x()):
		move(West)
	for k in range(get_pos_y()):
		move(South)
###
def hvPlLoop(crop):
	if(crop == Entities.Pumpkin):
		pumpkinLoop()
	else:
		for k in range(get_world_size()):
			for j in range(get_world_size()):
				if(can_harvest() or get_entity_type() == Entities.Dead_Pumpkin):
					harvest()
				if(crop == Entities.Tree):
					if(validTreePlacement()):
						plant(crop)
				else:
					plant(crop)
				if(get_water() <= 0.35):
					use_item(Items.Water)
				move(East)
			move(North)
###
def pumpkinLoop():
	def fullPumpk():
		for k in range(get_world_size()):
			for j in range(get_world_size()):
				if(can_harvest() or get_entity_type() == Entities.Dead_Pumpkin):
					harvest()
				plant(Entities.Pumpkin)
				move(East)
			move(North)
	
	def loopUntillAllAlive():
		valid = False
		while not valid:
			resetPos()
			valid = True
			for k in range(get_world_size()):
				for j in range(get_world_size()):
					if(get_entity_type() == Entities.Dead_Pumpkin):
						plant(Entities.Pumpkin)
						valid = False
					move(East)
				move(North)
	#
	fullPumpk()
	loopUntillAllAlive()
	harvest()
	resetPos()
###
def cactusLoop():
	def fullCacti():
		for k in range(get_world_size()):
			for j in range(get_world_size()):
				if(can_harvest()):
					harvest()
				plant(Entities.Cactus)
				move(East)
			move(North)
	
	def sortRow(rowNum):
		valid = False
		while not valid:
			valid = True
			for i in range(get_world_size()):
				if(get_pos_x() == get_world_size() - 1):
					break
				if(measure() > measure(East)):
					swap(East)
					valid = False
				move(East)
		#
	
	def sortCol(colNum):
		pass
	
	def sortAll():
		for k in range(get_world_size()):
			resetPos()
			for j in range(k):
				move(North)
			sortRow(k)
		
	#
	#fullCacti()
	sortAll()
	resetPos()
	#harvest()
###