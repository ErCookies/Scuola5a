clear()
for k in range(get_world_size()):
	for j in range(get_world_size()):
		harvest()
		till()
		move(East)
	move(North)