while True:
	if can_harvest():
		harvest()
		plant(Entities.Grass)
		if get_water() < 0.95:
			use_item(Items.Water)