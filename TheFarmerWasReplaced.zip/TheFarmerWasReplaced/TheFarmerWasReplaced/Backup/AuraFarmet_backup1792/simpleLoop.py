import modf

PLANTS = (Entities.Grass,
			Entities.Tree,
			Entities.Carrot,
			Entities.Pumpkin,
			Entities.Cactus)

while True:
	for crop in PLANTS:
		modf.hvPlLoop(crop)