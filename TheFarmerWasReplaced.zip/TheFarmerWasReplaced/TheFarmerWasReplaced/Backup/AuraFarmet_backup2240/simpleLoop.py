import modf

PLANTS = (Entities.Grass,
			Entities.Tree,
			Entities.Carrot,
			Entities.Pumpkin,
			Entities.Cactus)

while True:
	for crop in PLANTS:
		modf.switchHat(random() * len(modf.HATS) // 1)
		modf.hvPlLoop(crop)