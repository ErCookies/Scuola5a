while True:
	for k in range(get_world_size()):
		for j in range(get_world_size()):
			if can_harvest