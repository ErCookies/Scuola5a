while True:
	if can_harvest():
		harvest()
	if get_pos_x() % 2 == 0:
		plant(Entities.Tree)
		if get_water() < 0.8:
			use_item(Items.Water)
	move(East)
	